class ProcessedPrompt < ApplicationRecord
end
